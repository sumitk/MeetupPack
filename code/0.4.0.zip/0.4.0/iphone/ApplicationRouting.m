/**
 * Appcelerator Titanium Mobile
 * This is generated code. Do not modify. Your changes will be lost.
 * Generated code is Copyright (c) 2009 by Appcelerator, Inc.
 * All Rights Reserved.
 */
#import <Foundation/Foundation.h>
#import "ApplicationRouting.h"

@interface NSData (Additions) 
- (NSData *) decode64;
+ (NSData *) dataWithHexString: (NSString *)hexString;
- (NSData *) AES128DecryptWithKey:(NSString *)key;
@end

@implementation ApplicationRouting

- (NSData*) resolveAppAsset:(NSURL*)url;
{
    return nil;
}

-(oneway void)release
{
	[super release];
}

-(id)retain
{
	return [super retain];
}

@end
