package ${config['appid']};

import org.appcelerator.titanium.TitaniumActivityGroup;

public class ${config['classname']}Activity extends TitaniumActivityGroup
{
}