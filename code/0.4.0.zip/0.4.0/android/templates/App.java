package ${config['appid']};

import org.appcelerator.titanium.TitaniumApplication;

public class ${config['classname']}Application extends TitaniumApplication {

}
